Summary
=======

This dataset (ml-latest-small) describes 5-star rating and free-text tagging activity from [MovieLens](http://movielens.org), a movie recommendation service. It contains 100836 ratings and 3683 tag applications across 9742 movies. These data were created by 610 users between March 29, 1996 and September 24, 2018. This dataset was generated on September 26, 2018.

Users were selected at random for inclusion. All selected users had rated at least 20 movies. No demographic information is included. Each user is represented by an id, and no other information is provided.

The data are contained in the files `links.csv`, `movies.csv`, `ratings.csv` and `tags.csv`. More details about the contents and use of all these files follows.

This is a *development* dataset. As such, it may change over time and is not an appropriate dataset for shared research results. See available *benchmark* datasets if that is your intent.

This and other GroupLens data sets are publicly available for download at <http://grouplens.org/datasets/>.


Usage License
=============

Neither the University of Minnesota nor any of the researchers involved can guarantee the correctness of the data, its suitability for any particular purpose, or the validity of results based on the use of the data set. The data set may be used for any research purposes under the following conditions:

* The user may not state or imply any endorsement from the University of Minnesota or the GroupLens Research Group.
* The user must acknowledge the use of the data set in publications resulting from the use of the data set (see below for citation information).
* The user may redistribute the data set, including transformations, so long as it is distributed under these same license conditions.
* The user may not use this information for any commercial or revenue-bearing purposes without first obtaining permission from a faculty member of the GroupLens Research Project at the University of Minnesota.
* The executable software scripts are provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of them is with you. Should the program prove defective, you assume the cost of all necessary servicing, repair or correction.

In no event shall the University of Minnesota, its affiliates or employees be liable to you for any damages arising out of the use or inability to use these programs (including but not limited to loss of data or data being rendered inaccurate).

If you have any further questions or comments, please email <grouplens-info@umn.edu>

摘要
=======

这个数据集（ml-latest-small）描述了来自[MovieLens]（http://movielens.org）的五星评级和自由文本标签活动，这是一个电影推荐服务。它包含了9742部电影的100836个评分和3683个标签应用。这些数据是由610个用户在1996年3月29日至2018年9月24日期间创建的。这个数据集是在2018年9月26日产生的。

用户是随机选择纳入的。所有被选中的用户都对至少20部电影进行了评分。没有包括人口统计信息。每个用户由一个ID代表，没有提供其他信息。

数据包含在文件`links.csv`，`movies.csv`，`ratings.csv`和`tags.csv`中。关于所有这些文件的内容和使用的更多细节如下。

这是一个*开发*的数据集。因此，它可能会随着时间的推移而改变，并不是一个适合分享研究成果的数据集。如果你的目的是这样，请看可用的*基准*数据集。

这个和其他GroupLens数据集可在<http://grouplens.org/datasets/>公开下载。


使用许可
=============

明尼苏达大学和任何相关的研究人员都不能保证数据的正确性，它对任何特定目的的适用性，或基于使用该数据集的结果的有效性。在以下条件下，该数据集可用于任何研究目的。

* 用户不得陈述或暗示来自明尼苏达大学或GroupLens研究小组的任何认可。
* 用户必须在使用该数据集所产生的出版物中承认对该数据集的使用（关于引用信息见下文）。
* 用户可以重新发布该数据集，包括转换，只要它是在这些相同的许可条件下发布。
* 用户在未获得明尼苏达大学GroupLens研究项目的教员许可的情况下，不得将此信息用于任何商业或创收的目的。
* 可执行的软件脚本是 "按原样 "提供的，没有任何明示或暗示的保证，包括但不限于对适销性和特定用途的适用性的暗示保证。它们的质量和性能的全部风险由你承担。如果程序被证明有缺陷，你要承担所有必要的服务、修理或纠正的费用。

在任何情况下，明尼苏达大学、其附属机构或雇员都不对你因使用或无法使用这些程序（包括但不限于数据丢失或数据不准确）而造成的任何损害负责。

如果你有任何进一步的问题或意见，请发电子邮件至<grouplens-info@umn.edu>。

Citation
========

To acknowledge use of the dataset in publications, please cite the following paper:

> F. Maxwell Harper and Joseph A. Konstan. 2015. The MovieLens Datasets: History and Context. ACM Transactions on Interactive Intelligent Systems (TiiS) 5, 4: 19:1–19:19. <https://doi.org/10.1145/2827872>


Further Information About GroupLens
===================================

GroupLens is a research group in the Department of Computer Science and Engineering at the University of Minnesota. Since its inception in 1992, GroupLens's research projects have explored a variety of fields including:

* recommender systems
* online communities
* mobile and ubiquitious technologies
* digital libraries
* local geographic information systems

GroupLens Research operates a movie recommender based on collaborative filtering, MovieLens, which is the source of these data. We encourage you to visit <http://movielens.org> to try it out! If you have exciting ideas for experimental work to conduct on MovieLens, send us an email at <grouplens-info@cs.umn.edu> - we are always interested in working with external collaborators.


Content and Use of Files
========================

Formatting and Encoding
-----------------------

The dataset files are written as [comma-separated values](http://en.wikipedia.org/wiki/Comma-separated_values) files with a single header row. Columns that contain commas (`,`) are escaped using double-quotes (`"`). These files are encoded as UTF-8. If accented characters in movie titles or tag values (e.g. Misérables, Les (1995)) display incorrectly, make sure that any program reading the data, such as a text editor, terminal, or script, is configured for UTF-8.


User Ids
--------

MovieLens users were selected at random for inclusion. Their ids have been anonymized. User ids are consistent between `ratings.csv` and `tags.csv` (i.e., the same id refers to the same user across the two files).


Movie Ids
---------

Only movies with at least one rating or tag are included in the dataset. These movie ids are consistent with those used on the MovieLens web site (e.g., id `1` corresponds to the URL <https://movielens.org/movies/1>). Movie ids are consistent between `ratings.csv`, `tags.csv`, `movies.csv`, and `links.csv` (i.e., the same id refers to the same movie across these four data files).


Ratings Data File Structure (ratings.csv)
-----------------------------------------

All ratings are contained in the file `ratings.csv`. Each line of this file after the header row represents one rating of one movie by one user, and has the following format:

    userId,movieId,rating,timestamp

The lines within this file are ordered first by userId, then, within user, by movieId.

Ratings are made on a 5-star scale, with half-star increments (0.5 stars - 5.0 stars).

Timestamps represent seconds since midnight Coordinated Universal Time (UTC) of January 1, 1970.


Tags Data File Structure (tags.csv)
-----------------------------------

All tags are contained in the file `tags.csv`. Each line of this file after the header row represents one tag applied to one movie by one user, and has the following format:

    userId,movieId,tag,timestamp

The lines within this file are ordered first by userId, then, within user, by movieId.

Tags are user-generated metadata about movies. Each tag is typically a single word or short phrase. The meaning, value, and purpose of a particular tag is determined by each user.

Timestamps represent seconds since midnight Coordinated Universal Time (UTC) of January 1, 1970.

引文
========

为了确认在出版物中使用该数据集，请引用以下论文。

> F. Maxwell Harper and Joseph A. Konstan. 2015. MovieLens数据集。历史和背景。ACM交互式智能系统（TiiS）5，4：19：1-19：19。<https://doi.org/10.1145/2827872>


关于GroupLens的进一步信息
===================================

GroupLens是明尼苏达大学计算机科学和工程系的一个研究小组。自1992年成立以来，GroupLens的研究项目已经探索了多个领域，包括。

* 推荐系统
* 在线社区
* 移动和无处不在的技术
* 数字图书馆
* 本地地理信息系统

GroupLens Research运营着一个基于协作过滤的电影推荐器MovieLens，它是这些数据的来源。我们鼓励你访问<http://movielens.org>来尝试一下! 如果你对MovieLens的实验工作有令人兴奋的想法，请给我们发电子邮件<grouplens-info@cs.umn.edu>--我们总是对与外部合作者合作感兴趣。


文件的内容和使用
========================

格式化和编码
-----------------------

数据集文件被写成[逗号分隔的值](http://en.wikipedia.org/wiki/Comma-separated_values)文件，有一个头行。包含逗号（`,`）的列用双引号（`"`）转义。这些文件被编码为UTF-8。如果电影标题或标签值（如Misérables, Les (1995)）中的重音字符显示不正确，请确保任何读取数据的程序，如文本编辑器、终端或脚本，都被配置为UTF-8。


用户标识
--------

MovieLens的用户是随机挑选出来的。他们的ID已经被匿名化。用户ID在`ratings.csv'和`tags.csv'之间是一致的（即，相同的ID在两个文件中指的是同一个用户）。


电影ID
---------

只有至少有一个评级或标签的电影才被包括在数据集中。这些电影ID与MovieLens网站上使用的ID一致（例如，ID`1`对应的URL <https://movielens.org/movies/1>）。电影ID在`ratings.csv`、`tags.csv`、`movies.csv`和`links.csv`之间是一致的（也就是说，同一个ID在这四个数据文件中指的是同一个电影）。


评分数据文件结构(Rates.csv)
-----------------------------------------

所有的评分都包含在`评分.csv`文件中。这个文件的每一行在标题行之后代表一个用户对一部电影的评分，其格式如下。

    userId,movieId,rating,timestamp

这个文件中的每一行都是按用户身份排序的，然后在用户内部按电影身份排序。

评级以5星为单位，以半星为增量（0.5星-5.0星）。

时间戳代表从1970年1月1日的协调世界时（UTC）午夜开始的秒数。


标签数据文件结构(tags.csv)
-----------------------------------

所有标签都包含在文件`tags.csv`中。这个文件在标题行之后的每一行代表一个用户应用于一部电影的一个标签，其格式如下。

    userId,movieId,tag,timestamp

这个文件中的行首先按用户身份排序，然后在用户内部按电影身份排序。

标签是用户生成的关于电影的元数据。每个标签通常是一个单字或短语。一个特定标签的意义、价值和目的是由每个用户决定的。

时间戳代表1970年1月1日协调世界时（UTC）午夜后的秒数。

Movies Data File Structure (movies.csv)
---------------------------------------

Movie information is contained in the file `movies.csv`. Each line of this file after the header row represents one movie, and has the following format:

    movieId,title,genres

Movie titles are entered manually or imported from <https://www.themoviedb.org/>, and include the year of release in parentheses. Errors and inconsistencies may exist in these titles.

Genres are a pipe-separated list, and are selected from the following:

* Action
* Adventure
* Animation
* Children's
* Comedy
* Crime
* Documentary
* Drama
* Fantasy
* Film-Noir
* Horror
* Musical
* Mystery
* Romance
* Sci-Fi
* Thriller
* War
* Western
* (no genres listed)


Links Data File Structure (links.csv)
---------------------------------------

Identifiers that can be used to link to other sources of movie data are contained in the file `links.csv`. Each line of this file after the header row represents one movie, and has the following format:

    movieId,imdbId,tmdbId

movieId is an identifier for movies used by <https://movielens.org>. E.g., the movie Toy Story has the link <https://movielens.org/movies/1>.

imdbId is an identifier for movies used by <http://www.imdb.com>. E.g., the movie Toy Story has the link <http://www.imdb.com/title/tt0114709/>.

tmdbId is an identifier for movies used by <https://www.themoviedb.org>. E.g., the movie Toy Story has the link <https://www.themoviedb.org/movie/862>.

Use of the resources listed above is subject to the terms of each provider.


Cross-Validation
----------------

Prior versions of the MovieLens dataset included either pre-computed cross-folds or scripts to perform this computation. We no longer bundle either of these features with the dataset, since most modern toolkits provide this as a built-in feature. If you wish to learn about standard approaches to cross-fold computation in the context of recommender systems evaluation, see [LensKit](http://lenskit.org) for tools, documentation, and open-source code examples.
电影数据文件结构 (movies.csv)
---------------------------------------

电影信息包含在文件`movies.csv`中。这个文件在标题行之后的每一行代表一部电影，其格式如下。

    movieId,title,genres

电影标题是手动输入或从<https://www.themoviedb.org/>导入的，并在括号中包括发行年份。这些标题可能存在错误和不一致的地方。

类型是一个管道分隔的列表，并从以下方面选择。

* 动作片
* 冒险类
* 动画片
* 儿童类
* 喜剧
* 犯罪
* 纪录片
* 戏剧
* 幻想
* 电影-黑社会
* 恐怖片
* 音乐剧
* 悬疑片
* 浪漫主义
* 科幻片
* 惊悚片
* 战争
* 西方
*（没有列出流派）。


链接数据文件结构(link.csv)
---------------------------------------

可用于链接到其他电影数据来源的标识符包含在文件`links.csv`中。这个文件在标题行之后的每一行都代表一部电影，其格式如下。

    movieId,imdbId,tmdbId

movieId是<https://movielens.org>使用的电影的标识符。例如，电影《玩具总动员》的链接为<https://movielens.org/movies/1>。

imdbId是<http://www.imdb.com>使用的电影的标识符。例如，电影《玩具总动员》的链接是<http://www.imdb.com/title/tt0114709/>。

tmdbId是<https://www.themoviedb.org>使用的电影的标识符。例如，电影《玩具总动员》的链接是<https://www.themoviedb.org/movie/862>。

对上述资源的使用要遵守每个提供者的条款。


交叉验证
----------------

先前版本的MovieLens数据集包括预先计算的交叉折线或执行这种计算的脚本。我们不再将这些功能与数据集捆绑在一起，因为大多数现代工具包都将其作为一个内置功能。如果你想了解推荐系统评估中交叉折线计算的标准方法，请参阅[LensKit](http://lenskit.org)，了解工具、文档和开源代码示例。
